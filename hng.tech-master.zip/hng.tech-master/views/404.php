<html>
    <?php include 'partials/header.php';?>
    <body>
        <div class="error-page">
            <?php include 'partials/navbar.php';?>
            <div class="container error-page-container">
                <h1>Lost your way? <h1>
                <h3>Don't feel bad, it happens to everyone.</h3>
                <h4>Well, now that you are here, you might as well find out more about the HNG internship by clicking on the links above or you can </h4> 
                <a class="error-page-btn" href="/">Go Home</a>
            </div>
        </div>
    </body>
</html>