<div class="modal fade bd-example-modal-sm" id="priceModal" tabindex="-1" role="dialog" aria-labelledby="priceModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-sm"  role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Support The Mission</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>

  